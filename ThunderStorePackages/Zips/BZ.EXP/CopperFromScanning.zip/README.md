# Copper From Scanning
Makes it so when you scan fragments you already know you now get 1 titanium and 1 copper instead of 2 titanium.
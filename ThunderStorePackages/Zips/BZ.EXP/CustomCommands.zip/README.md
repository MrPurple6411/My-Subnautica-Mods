# Custom Commands
Commands

- spse [ID] [quantity] [size-X] [size-Y] [size-Z] [distance]:
    
    New spawn command that can change size
    
- suse [ID] [size-X] [size-Y] [size-Z] [distance]:
    
    New sub command that can change size
    
- size [size-X] [size-Y] [size-Z]:
    
    Set the size of the object you are aiming at
    
- friend:
    
    Sets the creatures you are aiming at to be docile, if the creatures already is docile it will remove it.
    
- pickup:
    
    Set the object you are aiming at to be able to be picked up, if the object already is able to be picked up, it will remove it.
    
- playse [size]:
    
    Set the size of the player. 
    
    *Changing the player size can cause a lot of problems so this command is very unstable!*
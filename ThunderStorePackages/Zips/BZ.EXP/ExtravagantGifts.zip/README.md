# Extravagant Gifts
Makes the monkey thiefs bring you better stuff when you have a recipe pinned, and makes it so they are not limited in what they are allowed to bring (i.e. Ion Cubes)
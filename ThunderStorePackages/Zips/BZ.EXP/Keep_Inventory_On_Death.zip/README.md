# Keep Inventory On Death
You get to keep all your items when you die instead of loosing newly picked up items.
# No Oxygen Warnings
The game no longer will warn you when running out of O2 even in survival or freedom modes.
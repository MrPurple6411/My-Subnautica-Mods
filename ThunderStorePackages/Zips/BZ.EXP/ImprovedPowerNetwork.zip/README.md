# Improved Power Network
Overhauls the power transmitter to be WAY more of a power network and will even let you pull power from Bases with nuke or bio reactors

- - has the option to increase or decrease length of beams
- - has the option to make the main beam require line of sight - off by default
# Better ACU
Overall Improvement of the Alien Containment Unit. Configurable number of allowable fish, Auto feed into bioreactors, Ampeel power generation, Ocean re-population capabilities.

Alien Containment Unit is configurable to allow between 10(default) up to 100 space inside. After the ACU reaches full capacity it will begin to put newly bred fish into bioreactors that are attached to the base.

If after all Bioreactors are full or if you have no Bio reactors then it will begin to release bred fish into the ocean to re-populate the area around your base.

[Disabled in menu by default] Overflowing into the ocean is currently set to release 1/10 of the total fish in the tank per day meaning if you have 10 fish in the tank it will only add 1 to the ocean per day.

Breeding Ampeels, Crabsquid or Ghost Leviathans in an ACU will give 500 power capacity per and power will be generated at a steady rate configurable in the menu.
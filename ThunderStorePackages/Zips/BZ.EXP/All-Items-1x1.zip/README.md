# All-Items-1x1
Changes all items to occupy one block of inventory space.
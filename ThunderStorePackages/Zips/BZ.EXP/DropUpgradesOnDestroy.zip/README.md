# Drop Upgrades On Destroy
This is a simple mod that will make vehicles drop any upgrades that were installed in it if the vehicle is destroyed.
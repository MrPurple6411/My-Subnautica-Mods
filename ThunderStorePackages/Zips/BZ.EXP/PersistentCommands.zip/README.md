# Persistent Commands
Saves active status commands like and "fastgrow" or "fog" to your save file so you don't haveto type them in every time you start your game.
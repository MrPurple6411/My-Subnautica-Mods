# Base Kits
This makes a new fabricator to make kits for base parts that can be used to build base parts from the single item kit instead of hauling all the mats
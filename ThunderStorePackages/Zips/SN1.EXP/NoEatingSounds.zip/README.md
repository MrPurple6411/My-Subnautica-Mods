# No Eating Sounds
For sufferers of [Misophonia](https://www.webmd.com/mental-health/what-is-misophonia).
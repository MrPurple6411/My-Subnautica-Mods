# Builder Place On Complete
Makes it so when you finish constructing something it automatically starts placement of another of said object.
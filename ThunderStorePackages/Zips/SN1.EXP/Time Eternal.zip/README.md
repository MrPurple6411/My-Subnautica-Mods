# Time Eternal
This mod effects daylight without breaking hunger, thirst, crafting speed or energy generation.

Currently Configurable to allow for always high noon, always midnight, or normal lighting.

This does not actually freeze time itself only the environmental lighting is effected. Meaning it should not break clocks or other time based events.
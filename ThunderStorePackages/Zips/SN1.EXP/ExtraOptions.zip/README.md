# Extra Options
Some visual options from the F3 menu put into the mod menu, as well as a few extra to allow for clearer water and clearer surface occlusion.
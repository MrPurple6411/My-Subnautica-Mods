# Seamoth Thermal Reactor
This mod is one part of the old MoreSeamothUpgrades Mod made by AHK1221 that I have taken the time to split into 4 parts.

This part holds the Thermal Reactor for the Seamoth so it can Charge in the Lava Biomes.

Permission given by AHK to remake the mod as individual parts All credit for this mod goes to AHK1221 for creating it.
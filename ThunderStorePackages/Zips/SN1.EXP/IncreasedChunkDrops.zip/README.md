# Increased Chunk Drops
Allows you to set how many items will drop while breaking things like limestone, sandstone, etc.
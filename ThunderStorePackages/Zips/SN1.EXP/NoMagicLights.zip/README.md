# Darker World
Immersion mod to remove the annoying ability of every single thing to be seen in the dark including rocks.
Things like kelp and limestone chunks and stuff are no longer easily seen even at night and in caves.
# No Crosshair
Immersion mod -- removes crosshair from HUD 

Optional override toggle: Hold F and press Left Mouse button
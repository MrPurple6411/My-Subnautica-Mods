# Island Cloud Removal

This Mod removes Removes the Clouds from the Islands when you are out of Graphic Rendering Range. 
This improves Game immersion by removing the Glitch with the tablet and also some random clouds that were SOO obviously hiding something.

You still wont be able to see the islands untill you get closer anyway as the terrain is not loaded till you get closer.
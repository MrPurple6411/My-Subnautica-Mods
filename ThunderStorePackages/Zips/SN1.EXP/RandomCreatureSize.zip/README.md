# Random Creature Size
Randomize fishy sizes based on menu config min/max
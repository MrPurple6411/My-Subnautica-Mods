# Tool Inspection
This mod allows you to press the i key while holding a tool and if the tool has an animation for the first time it is equipped then it will replay that animation for you.

How to use? Hold a tool in your hand ....... Press the i key.

Wait X Tool isn't doing anything WHY NOT!? Not all tools have a first use animation. Only tools that have said animation will play it.
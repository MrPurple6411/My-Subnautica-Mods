# Unknown Name
Both Modes

- - Disables knowing the names of anything before you have scanned it.
- - Disables crafting knowledge until all recipe materials have been scanned.
- - Also has an option to auto scan things when picking them up if you have a powered scanner in your inventory

Hardcore Mode in menu:

- - Disables even seeing recipes until all mats have been scanned
- - Gives scanner at picking up first item as without it you would never be able to get one
- - Makes it so you have to scan absolutely EVERYTHING before it can be used in crafting even if it never needed scanning before, including titanium, copper, etc
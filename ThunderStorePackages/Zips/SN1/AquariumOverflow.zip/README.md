# Aquarium Overflow
We have mods for breeding in aquariums and we have mods to add bio reactors to the cyclops ...... well this makes it so that excess fish in Aquariums get put automatically into the Cyclops BioReactors.

It should go without saying that this mod requires you to have both Aquarium Breeding mod as well as the Cyclops BioReactor mod installed for it to work.
# More Seamoth Depth Modules
This mod is one part of the old MoreSeamothUpgrades Mod made by AHK1221 that I have taken the time to split into 4 parts.

This part holds the MK4 and MK5 depth modules for the Seamoth so it can also travel down to max depth.

Permission given by AHK to remake the mod as individual parts All credit for this mod goes to AHK1221 for creating it.
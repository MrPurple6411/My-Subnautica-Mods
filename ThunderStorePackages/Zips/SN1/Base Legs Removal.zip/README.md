# Base Legs Removal
Mod to configure the different base parts to allow legs or not.

Very Basic mod with ingame config to disable certain base parts from making legs when building them.
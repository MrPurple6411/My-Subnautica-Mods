# Scannable Time Capsules
Allows scanner rooms to be able to scan for Time Capsules.
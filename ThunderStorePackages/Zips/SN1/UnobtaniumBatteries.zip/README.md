# Unobtanium Batteries
Batteries that are VERY hard to get that contain infinite power.
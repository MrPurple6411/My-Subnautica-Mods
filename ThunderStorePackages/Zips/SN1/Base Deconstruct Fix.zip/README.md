# Base Deconstruct Fix
Fixed the Recipes when Deconstructing Corridor parts.

When Deconstructing in vanilla Subnautica the corridors all only give back 2 titanium or 2 glass instead of the correct recipe for the part being deconstructed.

This mod fixes that so that you can now get the correct parts for the correct part that is being deconstructed, which allows them to also be modified by CC2 and SMLHelper and correctly give back the altered recipes.
# Fabricator No Auto Close
Stops the fabricator from closing while crafting so you can more easily select a follow up craft. Same thing as holding shift while crafting but automatic.
# Specialty Manifold
Allows the specialty tanks from Nitrogen mod or Deathrun mod to be used with the Scuba Manifold mod.
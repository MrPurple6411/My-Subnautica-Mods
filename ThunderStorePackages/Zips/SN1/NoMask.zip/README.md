# No Mask
Automatically removes the mask texture from around the screen that annoys some people. pretty much auto f6.
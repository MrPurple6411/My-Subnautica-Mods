# Increased Resource Spawns
Mod to increase the spawn of resources in the world.

This mod configures the number of times the game will try to find something to spawn when it is trying to spawn resources.
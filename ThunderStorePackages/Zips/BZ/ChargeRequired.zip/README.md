# Charge Required
Makes it so that when crafting things that require a battery as an ingredient to craft they will fail when trying to use a dead battery.
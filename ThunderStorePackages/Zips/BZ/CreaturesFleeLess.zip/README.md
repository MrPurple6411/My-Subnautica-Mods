# Creatures Flee Less
When attacking creatures it makes them not run away at the smallest damage meaning hostile creatures care less about your silly little butter knife.